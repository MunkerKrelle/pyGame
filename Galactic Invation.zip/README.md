Itch.io: https://munker-krelle.itch.io/galatic-invation 
Assets kan godt give problemer hvis de ikke bliver loaded rigtigt, alt efter hvilket path projected er i. 
vi har løst dette ved at have individuelle paths som vi skulle ændre efter hvert merge. 
Hvis du støder i problemer med assets så er det fordi du skal sætte deres path til det rigtige.

menu:
tryk på play for at spille, options for at lade som om vi har options, og quit for at quitte.

GamePlay:
WASD til movement
spacebar til at skyde.
når du har clearet et level (enemies killed), så skal du trykke på 1-4 på keyboarded(numpad kan ikke bruges)
1 giver dig en fireball power up
2 giver dig multishot
3 giver dig movement speed
4 giver dig 5 extra liv. 

Du kan også fake dine power ups med vores debug knapper:
f,g,h,v

f giver dig speed,
g giver fireball
h giver multi shot
v giver speed
(når du clearer et level skal knapperne 1-4 bruges og ikke debug knapperne.)